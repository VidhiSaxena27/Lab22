import java.io.*; 
class first
{
    public static void main(String args[])throws IOException
    {
        InputStreamReader ir= new InputStreamReader(System.in);
        BufferedReader br= new BufferedReader(ir);
        System.out.println("Hello World");
    }
}