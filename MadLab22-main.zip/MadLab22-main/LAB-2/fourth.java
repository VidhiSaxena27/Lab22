public class fourth {
    fourth() {
        System.out.println("Hello JUET");
    }

    public static void main(String args[]) {
        fourth b = new fourth();
    }
}
